export const CATEGORIES = [
    {name: "Breakfast", id: 'breakfast'},
    {name: "Snack", id: 'snack'},
    {name: "Lunch", id: 'lunch'},
    {name: "Dinner", id: 'dinner'},
]
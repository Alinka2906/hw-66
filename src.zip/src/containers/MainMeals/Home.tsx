import React from 'react';
import {Meals, PageMeal} from "../../types";
import MealsItem from "./MealsItem";
import {NavLink} from 'react-router-dom';
import axiosApi from '../../axiosApi';

interface Props {
    newMeals: Meals[];
    fetchMeals: () => void;
    mealsLoading: boolean;
}

const Home: React.FC<Props> = ({newMeals, fetchMeals}) => {
  const deleteMeal = async (id: string) => {
    if (window.confirm('Do you really want to delete this meal?')) {
      await axiosApi.delete('/dishes/' + id + '.json');
      await fetchMeals();
    }
  };

  const totalCalories = newMeals.reduce((sum, newMeals) => {
    return sum + newMeals.calories;
  }, 0)


    return (
        <>
          <div className="d-flex justify-content-around pt-4 pb-4">
            <h4>Total calories</h4>
            <h4 className='text-danger'><strong>{totalCalories}</strong></h4>
          <NavLink to='/meals-form' className='btn btn-primary'>Add new meal</NavLink>
          </div>
          <div className='d-flex flex-wrap'>
            {newMeals.map((newMeal) => (
                <MealsItem  key={newMeal.id} newMeals={newMeal} onDelete={() => deleteMeal(newMeal.id)}/>
            ))}
          </div>
        </>

    );
};



export default Home;
import React from 'react';
import {CartMeal, Meals} from "../../types";
import axiosApi from "../../axiosApi";
import Spinner from "../../components/Spinner/Spinner";
import PageMeals from '../../components/Page/PageMeals';

interface Props {
    mealsLoading: boolean;
    meals: Meals[];
    addToPage: (dish: Meals) => void;
    pageMeals: CartMeal[];
    fetchMeals: () => void;
}

const Home: React.FC<Props> = ({mealsLoading, meals, addToPage, pageMeals, fetchMeals}) => {


     return (
        <div className="row mt-2">
            <div className="col-7">
                {mealsLoading ? <Spinner/> : (
                   <PageMeals pageMeals={pageMeals}/>
                )}
            </div>
        </div>
    );
};

export default Home;
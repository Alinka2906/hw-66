import React from 'react';

const NavBar = () => {

    return (
        <div className="navbar navbar-expand-sm navbar-dark bg-primary">
            <div className='container-fluid'>
                <span><strong>Calories tracker</strong></span>
            </div>
        </div>
    );
};

export default NavBar;